#!/bin/bash
#PBS -l walltime=10:00:00
#PBS -j oe
#PBS -N iozone_test
#PBS -q mei

cat $PBS_NODEFILE
dmesg | grep -C3 sda

cd /opt/iozone/bin

./iozone -Ra -b ~/ESC/tpc2/graph.wks -g 1G -f /share/jade/pg27757/temp.tmp
