##!/bin/bash
#PBS -l walltime=10:00:00
#PBS-j oe
#PBS -N perf

cat $PBS_NODEFILE

cd ~/ESC/tpc4/

gcc -O3 -ggdb -o naive naive.c

perf list

perf stat -e cycles,instructions ./naive
perf stat -e cache-references,cache-misses ./naive
perf stat -e cpu-clock,faults ./naive

cd ~/ESC/tpc4/FlameGraph/

gcc -O3 -ggdb -o naive naive.c

perf record -g ./naive
perf script  | ./stackcollapse-perf.pl | ./flamegraph.pl > perf-kernel.svg

grep -v cpu_idle out.perf-folded | ./flamegraph.pl > nonidle.svg

#grep ext4 out.perf-folded | ./flamegraph.pl > ext4internals.svg

#egrep 'system_call.*sys_(read|write)' out.perf-folded | ./flamegraph.pl > rw.svg

perf report -v --stdio --sort comm,dso
perf report -v --stdio --dsos=naive
perf annotate -v --stdio --dsos=naive --symbol=multiply_matrices --no-source

